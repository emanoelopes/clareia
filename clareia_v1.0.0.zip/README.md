# Clareia: Sistema de Identifcação de Dificuldades de Aprendizagem

Sistema de identificação de dificuldades de aprendzagem por meio de IA.

Produto Educacional Digital para compor os requisistos exigidos pelo Mestrado Profissional em Tecnologia Educacional.

## 🐳 Execução com Docker (Recomendado)

O projeto está totalmente configurado para execução em qualquer dispositivo usando Docker:

```bash
# Execução simples
docker-compose up -d

# Acesse: http://localhost:8501
```

### Comandos Docker Compose:
- `docker-compose up -d` - Executar em background
- `docker-compose down` - Parar serviços
- `docker-compose logs -f` - Ver logs em tempo real
- `docker-compose --profile dev up -d` - Modo desenvolvimento

