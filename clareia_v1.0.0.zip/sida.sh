#!/bin/bash

source ./venv/bin/activate
streamlit run webapp/home.py

 