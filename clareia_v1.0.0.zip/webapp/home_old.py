import streamlit as st


st.sidebar.markdown(
    '''
    Mestrado Profissional
    PPGTE
    IUVI

    Orientador: 
    Prof. Leonardo Oliveira Moreira

    Aluno:
    [Emanoel Lopes](http://emanoel.pro.br)
    '''
    )

st.markdown('# Sistema de Identificação de Dificuldades de Aprendizagem ')
st.divider()

# Display the dataframe from session state
if "df_uci" in st.session_state:
    st.dataframe(st.session_state["df_uci"])
else:
    st.write("Nenhum dado disponível. Por favor, navegue para a página UCI primeiro.")

st.markdown(
    '''

    # Purpureo bracchia cognitus dedit

    ## Pedum ubi puer hunc

    Lorem markdownum oppositas. Pes est, ne `matrix_leaf`, tene sacris oraque.

    ## Pulsoque gravitate humum flumina

    Petit ademit hunc hosti cum dictis Piscique moenibus capitis, plena, et. Minores
    virgo. Ille iaculo ait Myrrha; artus altae nobis me ardua speque nostro.

    - Illo cum fuit quoque concumbere quem perdidit
    - Motura Semeleia conlegit
    - Cornua funera irae nulla

    ## Amor est nunc lancea

    Adit funera excute tempore caelum, ducit per; trementem superesse: nata. Decor
    **alumno**, ulla imperat, regis, erat mihi *viso grege* accepto tua quicquam
    levior. Sit age nam, tum mersit summa, iras corona. Fregit agros tendentemque
    umbras.

    Altissima noctis; et meritum e animo hiatu Agenorides ad statuit minimos stabat
    unam hanc aris temeraria una turba. Mea invidiosa fugitque, et traxere et
    numinis optima ego tria mea `word_menu` sanguine audent, iam dolens tamen. Ne
    emittere **tenera**, clademque perstant Hodites, retexitur haut, opus paratas
    meritorum, nisi est tertia. [Victoria stipite
    nascentur](#pulsoque-gravitate-humum-flumina) versata.

    ## Clarum genero in utilius

    Detrusit est *clade bos exiguo* pendeat habent sed. Vinci tua persequar, sunt
    manu quoque quaque adventu. Patiemur vivusque sopor **quies** quo inarata
    *locuta senex* nomen ignotae quis inmensi, languore quaeras, secum thalami
    lacertis, triplices!

    Ego **carpit annos** Ixion tamen *oculos*, natum etiam **non**, quod abit
    `tigerAssociation` ad: linguae gelidas mediis. Multa non foret, **Phoebeius**
    vites: agris nec cantare, Ide. Vicit fatis.
    '''
)
