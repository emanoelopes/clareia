def main():
    print("Hello from sida!")


if __name__ == "__main__":
    main()
